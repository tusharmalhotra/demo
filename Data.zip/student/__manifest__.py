{
    'name': 'Student',
    'summary': 'Student Data',
    'description' : 'This is use for testing purpose',
    'authon' : 'Tushar_Malhotra',
    'license' : 'AGPL-3',
    'website' : 'https://www.ksolves.com',
    'category' : 'Uncategorized',
    'version' : '11.0.1.1.0',
    'depends' : ['base'],
    'data' : [],
    # 'demo' : ['demo.xml'],
}