{
    'name': 'Library Books',
    'summary': 'Manage your Books',
    'description' : 'This is use for testing purpose',
    'authon' : 'Tushar_Malhotra',
    'license' : 'AGPL-3',
    'website' : 'https://www.ksolves.com',
    'category' : 'Library',
    'version' : '11.0.1.1.0',
    'depends' : ['base'],
    'data' : ['views/library_book.xml','security/security.xml','security/ir.model.access.csv'],
    # 'demo' : ['demo.xml'],
}

