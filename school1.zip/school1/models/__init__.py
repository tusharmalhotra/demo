from . import school_model
from . import subject_data
from . import student_data
from . import class_data
from . import teacher_data
from . import exam_data
from . import exam_wizard

